// hamburger menu with the help of the youtube channel Web Dev Simplified
///////////////////////////////////////////////////////////////////////////////
const toggleButtonjs = document.getElementsByClassName('toggleButton')[0]
const navBarLinksjs = document.getElementsByClassName('navBarLinks')[0]

toggleButtonjs.addEventListener('click', () => {navBarLinksjs.classList.toggle('active')})
////////////////////////////////////////////////////////////////////////////////////////////////

//code adapted from a youtuber called Hyperplexed
/////////////////////////////////////////////////////////
const letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

let interval = null;

document.querySelector("span").onmouseover = event => {  
  let iteration = 0;
  
  clearInterval(interval);
  
  interval = setInterval(() => {
    event.target.innerText = event.target.innerText
      .split("")
      .map((letter, index) => {
        if(index < iteration) {
          return event.target.dataset.value[index];
        }
        return letters[Math.floor(Math.random() * 26)]
      })
      .join("");
    if(iteration >= event.target.dataset.value.length){ 
      clearInterval(interval);
    }
    iteration += 1 / 3;
  }, 30);

  
}
///////////////////////////////////////////////////////////////////


//(The IIE, 2023) and (w3schools, 2023)
////////////////////////////////////////////////////
var theDate=new Date()
var theModifiedDate=new Date(document.lastModified)
document.getElementById("autoDate").innerHTML = "&copy; " + theDate.getFullYear() + " - TylCreativeStainedGlass | Lastmodified: " + theModifiedDate.toDateString(); 
////////////////////////////////////////////////////