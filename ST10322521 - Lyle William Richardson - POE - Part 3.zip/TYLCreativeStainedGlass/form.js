//(W3schools, 2023)
/////////////////////////////////////////////////////////////////////////////////////////
function validateEmail(emailId) {
    var mailformat = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
    if(emailId.value.match(mailformat)) {
        document.myForm.subject.focus();
        return true;
    }
    else{
        alert("Invalid email address.");
        return false;    
    } 
}

function validateName(nameId) {
    if (nameId.value.trim() == "") {
        alert("Please enter your name.");
        return false;
    }
    else {
        document.myForm.email.focus();
        return true;
    }   
}
///////////////////////////////////////////////////////////////////////////////////////// 