  // lightbox addapted from w3school code
  ////////////////////////////////////////////////

  function openModal() { //opens the displayed images into a lightbox
    document.getElementById("myModal").style.display = "block";
  }
  
  function closeModal() { //closes the light box
    document.getElementById("myModal").style.display = "none";
  }
  
  var slideIndex = 1;
  showSlides(slideIndex);
  
  //allows the next and previous buttons to work
  function plusSlides(n) {
    showSlides(slideIndex += n);
  }
  
  //allows you to switch between images on the lightbox by clicking on them
  function currentSlide(n) {
    showSlides(slideIndex = n);
  }
  
  function showSlides(n) {
    var i;
    var slides = document.getElementsByClassName("mySlides");
    var dots = document.getElementsByClassName("slideImg");
    if (n > slides.length) {slideIndex = 1}
    if (n < 1) {slideIndex = slides.length}
    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
    }
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace("active", "");
    }
   
    slides[slideIndex-1].style.display = "flex";
    dots[slideIndex-1].className += " active";
  }
  ///////////////////////////////////////////////////////////